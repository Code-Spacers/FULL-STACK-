const dataUrl = (name) => new URL(`../../data/${name}.json`, import.meta.url);
export async function loadMockData(name) {
  const response = await fetch(dataUrl(name));
  if (!response.ok)
    throw new Error(`Could not load ${name} mock data (${response.status})`);
  return response.json();
}
export const delay = (ms = 300) =>
  new Promise((resolve) => window.setTimeout(resolve, ms));
export function readLocalList(key, fallback = []) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : fallback;
  } catch {
    return fallback;
  }
}
export function writeLocalList(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
  return value;
}
