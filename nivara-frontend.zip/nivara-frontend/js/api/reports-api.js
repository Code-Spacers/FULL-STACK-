import { delay, readLocalList, writeLocalList } from "./api.js?v=20261020d";
import { apiFetch, normaliseReport, stripServerFields } from "./backend.js?v=20261020d";

const KEY = "nivara.reports";

// Citizen-facing totals represent reports submitted in this browser. Authority
// demo fixtures remain in reports.json for the operational screens.
//
// When the backend is running the same records are kept in MongoDB, so the
// numbers survive a browser change and stay shared between the citizen portal
// and the authority console. Every call falls back to localStorage, so the
// app still works as a static site with no server.

export async function listReports() {
  try {
    const dbReports = await apiFetch("/reports");
    if (Array.isArray(dbReports)) {
      const clean = dbReports.map(normaliseReport);
      writeLocalList(KEY, clean);
      return clean;
    }
  } catch {
    // Backend offline — serve the browser-local copy.
  }
  await delay(80);
  return readLocalList(KEY);
}

export async function createReport(report) {
  const payload = {
    id: `NVR-${String(Date.now()).slice(-5)}`,
    status: "Reported",
    priority: report.priority || "Medium",
    reportedAt: new Date().toLocaleString(),
    updates: ["Report received"],
    ...report,
    department: report.department || ({ Pothole: "Roads & Civil Works", "Road Damage": "Roads & Civil Works", Sidewalk: "Roads & Civil Works", Garbage: "Sanitation", Streetlight: "Electrical Quick Response", Drainage: "Water & Drainage", Water: "Water & Drainage" }[report.category] || "Roads & Civil Works"),
    ward: report.ward || "Ward pending",
    slaHours: report.slaHours ?? ({ Critical: 4, High: 12, Medium: 24, Low: 36 }[report.priority] || 24),
  };

  try {
    const saved = await apiFetch("/reports", {
      method: "POST",
      body: JSON.stringify(stripServerFields(payload)),
    });
    if (saved) {
      const clean = normaliseReport(saved);
      writeLocalList(KEY, [clean, ...readLocalList(KEY)]);
      window.dispatchEvent(
        new CustomEvent("nivara:report-created", { detail: clean }),
      );
      return clean;
    }
  } catch {
    // Backend offline — keep the record in the browser only.
  }

  await delay(450);
  writeLocalList(KEY, [payload, ...readLocalList(KEY)]);
  window.dispatchEvent(
    new CustomEvent("nivara:report-created", { detail: payload }),
  );
  return payload;
}

export async function updateReport(id, patch) {
  try {
    const updatedDoc = await apiFetch(`/reports/${id}`, {
      method: "PATCH",
      body: JSON.stringify(stripServerFields(patch)),
    });
    if (updatedDoc) {
      const clean = normaliseReport(updatedDoc);
      const items = readLocalList(KEY);
      writeLocalList(
        KEY,
        items.map((item) => (item.id === id ? { ...item, ...clean } : item)),
      );
      return clean;
    }
  } catch {
    // Backend offline — keep the change in the browser only.
  }

  const items = readLocalList(KEY);
  const updated = items.map((item) =>
    item.id === id ? { ...item, ...patch } : item,
  );
  writeLocalList(KEY, updated);
  return updated.find((item) => item.id === id) || null;
}
