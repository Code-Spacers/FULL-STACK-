// Unit tests for the NIVARA guide chatbot intent engine.
// Run: node --test tests/chatbot.test.cjs

const test = require("node:test");
const assert = require("node:assert/strict");
const { matchIntent, answer, renderRich, normalizeTranscript, shouldAutoSend, KB } = require("../js/chatbot.js");

test("knowledge base covers the main site flows", () => {
  const ids = KB.map((e) => e.id);
  for (const expected of [
    "greeting", "help", "about", "sdg11", "navigation", "report", "track",
    "my_reports", "map", "login", "demo", "authority", "live_city",
    "challenges", "solutions", "calculator", "privacy", "troubleshoot",
    "accessibility", "thanks", "bye",
  ]) {
    assert.ok(ids.includes(expected), `missing intent: ${expected}`);
  }
});

test("reporting questions resolve to the report intent", () => {
  for (const q of [
    "how do i report an issue",
    "i want to complain about a pothole",
    "where do i file a complaint",
    "how to report a broken streetlight",
  ]) {
    assert.equal(matchIntent(q).intent.id, "report", q);
  }
});

test("tracking questions resolve to the track intent", () => {
  for (const q of [
    "how do i track my report",
    "check the status of my complaint NVR-1000",
    "what is my reference number status",
  ]) {
    assert.equal(matchIntent(q).intent.id, "track", q);
  }
});

test("map, login, authority and console questions", () => {
  assert.equal(matchIntent("where can i see the map").intent.id, "map");
  assert.equal(matchIntent("open the city map").intent.id, "map");
  assert.equal(matchIntent("how do i sign in").intent.id, "login");
  assert.equal(matchIntent("how do officers log in").intent.id, "authority");
  assert.equal(matchIntent("what is the otp step").intent.id, "authority");
  assert.equal(matchIntent("how do i open the triage console").intent.id, "authority");
});

test("authority sign-in beats plain sign-in when both are present", () => {
  assert.equal(matchIntent("how do i sign in as an authority officer").intent.id, "authority");
});

test("section questions resolve to their sections", () => {
  assert.equal(matchIntent("show me the live city dashboard").intent.id, "live_city");
  assert.equal(matchIntent("what are the six pillars").intent.id, "sdg11");
  assert.equal(matchIntent("how does the calculator work").intent.id, "calculator");
  assert.equal(matchIntent("explain the challenges section").intent.id, "challenges");
  assert.equal(matchIntent("tell me about the solutions").intent.id, "solutions");
});

test("demo credentials, privacy and troubleshooting", () => {
  assert.equal(matchIntent("which demo account can i use").intent.id, "demo");
  assert.equal(matchIntent("what password for the citizen demo").intent.id, "demo");
  assert.equal(matchIntent("who can see my data").intent.id, "privacy");
  assert.equal(matchIntent("where is my data stored").intent.id, "privacy");
  assert.equal(matchIntent("the map is blank and not loading").intent.id, "troubleshoot");
  assert.equal(matchIntent("the site shows a blank page").intent.id, "troubleshoot");
});

test("small talk and fallback", () => {
  assert.equal(matchIntent("hello").intent.id, "greeting");
  assert.equal(matchIntent("thanks a lot").intent.id, "thanks");
  assert.equal(matchIntent("goodbye").intent.id, "bye");
  assert.equal(matchIntent("who are you").intent.id, "assistant");
  assert.equal(matchIntent("xyzzy plugh banana").intent.id, "fallback");
  assert.equal(matchIntent("").intent.id, "fallback");
});

test("voice questions resolve to the voice intent", () => {
  for (const q of [
    "how do i use the microphone",
    "can i speak my question instead of typing",
    "does this site have voice input",
    "i want to dictate my report",
  ]) {
    assert.equal(matchIntent(q).intent.id, "voice", q);
  }
});

test("normalizeTranscript tidies dictation for review", () => {
  assert.equal(normalizeTranscript("  hello   world \n"), "Hello world");
  assert.equal(normalizeTranscript(""), "");
  assert.equal(normalizeTranscript(null), "");
  assert.equal(normalizeTranscript("how do i report an issue"), "How do i report an issue");
  assert.equal(normalizeTranscript("NVR-1000 status"), "NVR-1000 status");
});

test("spoken transcript auto-sends, unless edited, busy, or closed", () => {
  const base = { transcript: "Open the map", panelOpen: true, pending: false, userEdited: false };
  assert.equal(shouldAutoSend(base), true);
  assert.equal(shouldAutoSend({ ...base, transcript: "   " }), false);
  assert.equal(shouldAutoSend({ ...base, transcript: "" }), false);
  assert.equal(shouldAutoSend({ ...base, userEdited: true }), false);
  assert.equal(shouldAutoSend({ ...base, pending: true }), false);
  assert.equal(shouldAutoSend({ ...base, panelOpen: false }), false);
  assert.equal(shouldAutoSend(null), false);
});

test("streetlight fault is a report, not a solution", () => {
  assert.equal(matchIntent("the streetlight outside my house is broken").intent.id, "report");
  assert.equal(matchIntent("solar streetlights are a good idea").intent.id, "solutions");
});

test("answer() returns reply text plus chips", () => {
  const res = answer("how do i report an issue");
  assert.equal(res.id, "report");
  assert.ok(res.reply.includes("citizen portal"));
  assert.ok(res.chips.length >= 1);
  assert.ok(res.chips.every((c) => c.label && (c.to || c.ask)));
});

test("my reports answer warns the page needs sign-in", () => {
  const res = answer("show me my reports");
  assert.equal(res.id, "my_reports");
  assert.ok(res.reply.includes("sign-in only"));
});

test("renderRich escapes HTML and formats bold/code/bullets", () => {
  const html = renderRich("Use `NVR-1000` and **bold** text\n• bullet line");
  assert.ok(!html.includes("<script"));
  assert.ok(html.includes("<code>NVR-1000</code>"));
  assert.ok(html.includes("<strong>bold</strong>"));
  assert.ok(html.includes('class="cb-line cb-bullet"'));
  const safe = renderRich('<script>alert(1)</script>');
  assert.ok(safe.includes("&lt;script&gt;"));
});
